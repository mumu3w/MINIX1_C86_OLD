/*	sample C program to get you started
	first you will have to unsqueeze:

	cc1.eqe cc2.eqe cc3.eqe cc4.eqe stdio.hq c86s2s.lqb

	and get a copy of LINK.EXE from your DOS distribution disk

	then run cc.bat to compile and link the program

	then run the program by typing:  HELLO
*/

#include <stdio.h>		/* standard header file */

main()
{

   printf("\nhello world\n");
}

